const scope = self.registration.scope;
const prefix = 'buildcontrol-prisma-' + new URL(scope).pathname + '-';
const cacheName = prefix + '611cc77b34de4138';
const shell = ['./index.html','./login.html','./prisma.css','./script.js','./modo.js','./pwa.js','./login.js','./manifest.json','./assets/geist-latin.woff2','./assets/wa-prisma-96.webp','./assets/icone.svg','./assets/planta.svg','./assets/planta-estatica.webp','./imagens/icon-192.png','./imagens/icon-512.png'];
const absolute = file => new URL(file,scope).href;
const assets = new Set(shell.map(absolute));
self.addEventListener('install', event => {
 event.waitUntil((async()=>{
   const cache=await caches.open(cacheName);
   await cache.addAll(shell.map(file=>new Request(absolute(file),{cache:'reload'})));
   await self.skipWaiting();
 })());
});
self.addEventListener('activate',event=>{
 event.waitUntil((async()=>{
  for(const key of await caches.keys()){
   if(key.startsWith(prefix) && key!==cacheName)await caches.delete(key);
   else if(/^buildcontrol-pwa-v\d+$/.test(key)){
    const old=await caches.open(key);
    for(const req of await old.keys())if(req.url.startsWith(scope))await old.delete(req);
    if(!(await old.keys()).length)await caches.delete(key);
   }
  }
  await self.clients.claim();
 })());
});
self.addEventListener('fetch',event=>{
 const request=event.request,url=new URL(request.url);
 if(request.method!=='GET'||url.origin!==self.location.origin)return;
 let key=url.origin+url.pathname;
 if(key===scope)key=absolute('./index.html');
 if(!assets.has(key))return;
 event.respondWith((async()=>{
   const cache=await caches.open(cacheName);
   return (await cache.match(key))||fetch(request);
 })());
});
