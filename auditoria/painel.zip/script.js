'use strict';
const previa = MODO_BUILD === 'previa';
const api = 'https://buildcontrol-api.vercel.app';
const chave = nome => (previa ? 'buildcontrol_previa_' : 'buildcontrol_') + nome;
const $ = id => document.getElementById(id);
const moeda = new Intl.NumberFormat('pt-BR', {style:'currency',currency:'BRL'});
const numero = new Intl.NumberFormat('pt-BR',{maximumFractionDigits:8});
const abreviado = new Intl.NumberFormat('pt-BR',{notation:'compact',maximumFractionDigits:1});
const meses = Array.from($('mesGuardado').options).slice(1).map(o=>o.value);
const icone = nome => '<svg class="icon" aria-hidden="true"><use href="#i-'+nome+'"></use></svg>';
const seguro = valor => String(valor??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const texto = (id,v) => { $(id).textContent=v; };
const ler = (k,def) => {const s=localStorage.getItem(k);return s===null?def:JSON.parse(s)};
const normalizar = s => String(s??'').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
const usuario=previa?null:ler('buildcontrol_user',null);
const sessao=previa?null:ler('buildcontrol_session',null);
const conta=usuario?.id || usuario?.email || sessao?.user?.id || sessao?.user?.email;
let materiais=[],guardados=[],editando=null,vista='home',busca='',filtro='Todos',revisao=0,sincronizando=false,conflito=null;
let dadosBloqueados=false;
const demo={materiais:[
  {nome:'Cimento CP II · 50 kg',quantidade:60,valor:42},{nome:'Tijolo cerâmico 14 × 11 × 24',quantidade:9000,valor:1.1},
  {nome:'Areia média lavada',quantidade:4,valor:180},{nome:'Vergalhão CA-50 · 10 mm',quantidade:52,valor:75},
  {nome:'Brita nº 1',quantidade:6,valor:230},{nome:'Tábua de pinus · 3 m',quantidade:45,valor:35}],
  guardados:['Junho','Julho','Agosto','Setembro','Outubro','Novembro'].map((mes,i)=>({mes,valor:[800,1350,1250,1900,1650,2400][i]}))};
function toast(msg){const el=document.createElement('div');el.className='toast';el.textContent=msg;$('toastContainer').replaceChildren(el);setTimeout(()=>el.remove(),3600)}
function status(msg){texto('syncStatus',msg)}
function salvarLocal(){
  localStorage.setItem(chave('materiais'),JSON.stringify(materiais));
  localStorage.setItem(chave('guardados'),JSON.stringify(guardados));
}
function lerBackup(){
  let m=ler(chave('materiais'),null),g=ler(chave('guardados'),null);
  if(previa && m===null && g===null)return structuredClone(demo);
  if(!previa && m===null)m=ler('materiais',[]).map(item=>({...item,nome:item.nome??item.material}));
  if(!previa && g===null)g=Object.entries(ler('guardado',{})).map(([mes,valor])=>({mes,valor}));
  if(!Array.isArray(m??[]) || !Array.isArray(g??[]))throw Error('Formato de backup desconhecido.');
  return {materiais:m??[],guardados:g??[]};
}
function valores(dados){return JSON.stringify([dados.materiais.map(i=>[i.nome,Number(i.quantidade),Number(i.valor)]),dados.guardados.map(i=>[i.mes,Number(i.valor)])])}
function dadosAtuais(){return {materiais,guardados}}
function preencher(dados){materiais=dados.materiais;guardados=dados.guardados;renderizar()}
function totais() {
  const totalMateriais = materiais.reduce((soma, item) => soma + Number(item.quantidade || 0) * Number(item.valor || 0), 0);
  const totalGuardado = guardados.reduce((soma, item) => soma + Number(item.valor || 0), 0);
  const faltaPagar = Math.max(totalMateriais - totalGuardado, 0);
  const percentual = totalMateriais > 0 ? Math.min(100, (totalGuardado / totalMateriais) * 100) : 0;
  return { totalMateriais, totalGuardado, faltaPagar, percentual };
}

function atualizarStatusAutomatico() {
  let saldo = totais().totalGuardado;
  materiais.forEach(item => {
    const total = Number(item.quantidade || 0) * Number(item.valor || 0);
    if (total > 0 && saldo >= total) {
      item.status = "Concluído";
      item.cobertura = 100;
      saldo -= total;
    } else if (total > 0 && saldo > 0) {
      item.status = "Parcial";
      item.cobertura = Math.min(100, (saldo / total) * 100);
      saldo = 0;
    } else {
      item.status = "Pendente";
      item.cobertura = 0;
    }
  });
}

function categoria(nome){
 const n=normalizar(nome);
 const classes=[[/cimento|argamassa|\bcal\b/,'Cimento e argamassa','cement'],[/tijolo|bloco/,'Alvenaria','brick'],[/areia|brita|pedra/,'Agregados','sand'],[/ferro|aco|vergalhao|coluna/,'Ferragens','iron'],[/madeira|tabua|caibro|ripa|pinus/,'Madeiras','wood'],[/telha/,'Cobertura','box'],[/fio|cabo|disjuntor|tomada/,'Elétrica','box'],[/cano|tubo|registro/,'Hidráulica','box'],[/tinta|massa corrida/,'Acabamento','box']];
 return classes.find(([re])=>re.test(n))?.slice(1)??['Outros','box'];
}
function mensais(){
 const mapa=new Map();
 for(const item of guardados){
   const mes=meses.find(m=>normalizar(m)===normalizar(item.mes))||item.mes;
   mapa.set(mes,(mapa.get(mes)||0)+Number(item.valor||0));
 }
 const indice=m=>meses.includes(m)?meses.indexOf(m):12;
 return [...mapa].sort(([a],[b])=>indice(a)-indice(b));
}
const coberturas={'Concluído':'Cobertura integral','Parcial':'Cobertura parcial','Pendente':'Sem cobertura'};
function controles(tipo,i,nome){
 const n=seguro(nome);
 return '<div class="ops"><button data-edit="'+tipo+'" data-id="'+i+'" aria-label="Editar '+n+'" title="Editar">'+icone('edit')+'</button><button data-remove="'+tipo+'" data-id="'+i+'" aria-label="Excluir '+n+'" title="Excluir">'+icone('delete')+'</button></div>';
}
function tabela(lista,completa){
 if(!lista.length)return '<p class="empty">'+(materiais.length?'Nenhum material corresponde ao filtro.':'Nenhum material cadastrado.')+'</p>';
 const linhas=lista.map(({item,i})=>{
  const [cat,fig]=categoria(item.nome),valor=Number(item.valor);
  const detalhe=completa?moeda.format(valor)+' por unidade · '+coberturas[item.status]:cat;
  return '<div class="row" role="row"><div role="cell" class="item"><span class="item-icon '+fig+'">'+icone(fig)+'</span><div><strong>'+seguro(item.nome)+'</strong><small>'+seguro(detalhe)+'</small></div></div><span role="cell" class="qty">'+numero.format(item.quantidade)+'</span><strong role="cell" class="value">'+moeda.format(item.quantidade*valor)+'</strong>'+(completa?'<div role="cell">'+controles('material',i,item.nome)+'</div>':'')+'</div>';
 }).join('');
 return '<div role="table" aria-label="Materiais da obra" class="rows '+(completa?'full-list':'')+'"><div class="cols" role="row"><span role="columnheader">Material</span><span role="columnheader">Qtd.</span><span role="columnheader">Total</span>'+(completa?'<span class="extra-col" role="columnheader">Ações</span>':'')+'</div>'+linhas+'</div>';
}
function listaMateriais(){
 const itens=materiais.map((item,i)=>({item,i}));
 const filtrados=itens.filter(({item})=>(filtro==='Todos'||filtro===item.status)&&normalizar(item.nome).includes(normalizar(busca)));
 $('listaMateriais').innerHTML=tabela(filtrados,true);
 $('materiaisRecentes').innerHTML=tabela(itens.slice(-6).reverse(),false)+'<div class="table-foot"><span>'+Math.min(materiais.length,6)+' de '+materiais.length+' materiais</span><strong>'+moeda.format(totais().totalMateriais)+'</strong></div>';
}
function grafico(dados){
 if(!dados.length)return '<p class="empty">Registre um valor para comparar os meses.</p>';
 const max=Math.max(1,...dados.map(([,valor])=>valor));
 const barras=dados.map(([mes,valor])=>'<div class="column" role="listitem" aria-label="'+seguro(mes)+' · '+moeda.format(valor)+'" title="'+seguro(mes)+' · '+moeda.format(valor)+'"><span class="bar-value" aria-hidden="true">'+abreviado.format(valor)+'</span><i class="bar" style="height:'+Math.max(1,Math.round(valor/max*112))+'px"></i><span class="month-label" aria-hidden="true">'+seguro(meses.includes(mes)?mes.slice(0,3):mes)+'</span></div>').join('');
 return '<div class="chart-unit">Valor guardado (R$)</div><div class="chart-plot" tabindex="0" role="region" aria-label="Valores mensais em reais"><div class="chart-inner" role="list" style="min-width:'+dados.length*44+'px">'+barras+'</div></div>';
}
function renderizar(){
 atualizarStatusAutomatico();
 const {totalMateriais,totalGuardado,faltaPagar,percentual}=totais(),mensal=mensais(),pct=Math.round(percentual)+'%';
 texto('totalMateriais',moeda.format(totalMateriais));texto('totalGuardado',moeda.format(totalGuardado));texto('faltaPagar',moeda.format(faltaPagar));
 texto('qtdMateriaisResumo',materiais.length+(materiais.length===1?' item cadastrado':' itens cadastrados'));
 texto('qtdMesesResumo',mensal.length+(mensal.length===1?' mês com reserva':' meses com reserva'));
 for(const id of ['progressoPercentual','relatorioPercentual'])texto(id,pct);
 for(const id of ['progressoBarra','relatorioBarra'])$(id).style.width=percentual+'%';
 texto('mediaGuardada',moeda.format(mensal.length?totalGuardado/mensal.length:0));
 texto('totalGuardadoPagina',moeda.format(totalGuardado));
 listaMateriais();
 for(const id of ['graficoGuardado','graficoReserva'])$(id).innerHTML=grafico(mensal);
 $('listaGuardado').innerHTML=guardados.map((it,i)=>'<div class="saving-row"><span>'+seguro(it.mes)+'</span><strong>'+moeda.format(it.valor)+'</strong>'+controles('guardado',i,it.mes)+'</div>').join('')||'<p class="empty">Nenhum valor registrado.</p>';
 const grupos=new Map();
 for(const it of materiais){const [cat]=categoria(it.nome);grupos.set(cat,(grupos.get(cat)||0)+it.quantidade*it.valor)}
 $('categoriasRelatorio').innerHTML=[...grupos].sort((a,b)=>b[1]-a[1]).map(([cat,v])=>'<div class="legend-row"><span>'+cat+'</span><span>'+Math.round(v/(totalMateriais||1)*100)+'%</span><strong>'+moeda.format(v)+'</strong></div>').join('')||'<p class="empty">Nenhum custo cadastrado.</p>';
 $('valoresRelatorio').innerHTML=[['Custo dos materiais',totalMateriais],['Dinheiro guardado',totalGuardado],['Falta cobrir',faltaPagar]].map(([k,v])=>'<div class="report-row"><dt>'+k+'</dt><dd>'+moeda.format(v)+'</dd></div>').join('');
}
const titulos={home:'Visão geral',materials:'Materiais',savings:'Dinheiro guardado',reports:'Relatórios',profile:'Configurações'};
function navegar(view,foco=true){
 vista=Object.hasOwn(titulos,view)?view:'home';
 document.querySelectorAll('.view').forEach(el=>el.hidden=el.dataset.view!==vista);
 document.querySelectorAll('.nav-item').forEach(btn=>{const ativo=btn.dataset.goView===vista;btn.classList.toggle('active',ativo);if(ativo)btn.setAttribute('aria-current','page');else btn.removeAttribute('aria-current')});
 texto('crumb',titulos[vista]);window.scrollTo(0,0);
 if(foco)$('view-'+vista).querySelector('h1').focus({preventScroll:true});
}
function abrir(tipo,i=null){
 if(dadosBloqueados)return;
 const mat=tipo==='material',frm=$(mat?'formMaterial':'formGuardado'),item=(mat?materiais:guardados)[i];
 editando={tipo,i,item};
 $('formMaterial').hidden=!mat;$('formGuardado').hidden=mat;frm.reset();
 $('modal').setAttribute('aria-labelledby',mat?'tituloMaterial':'tituloGuardado');
 if(mat){
  texto('tituloMaterial',item?'Editar material':'Adicionar material');$('nomeMaterial').value=item?.nome??'';$('quantidadeMaterial').value=item?.quantidade??'';$('valorMaterial').value=item?.valor??'';
 }else{
  texto('tituloGuardado',item?'Editar valor guardado':'Registrar valor guardado');
  const sel=$('mesGuardado');sel.querySelector('[data-antigo]')?.remove();
  if(item && !meses.includes(item.mes)){const o=new Option(item.mes,item.mes);o.dataset.antigo='';sel.add(o)}
  sel.value=item?.mes??'';$('valorGuardadoInput').value=item?.valor??'';
 }
 $('modal').showModal();$(mat?'nomeMaterial':'mesGuardado').focus();
}
function fechar(){if($('modal').open)$('modal').close();editando=null}
function alterou(msg){
 revisao++;atualizarStatusAutomatico();
 if(sessao && !previa)localStorage.setItem(chave('pendente'),'1');
 salvarLocal();renderizar();toast(msg);if(sessao && !previa)void sincronizar();
}
function salvarForm(e){
 e.preventDefault();if(!editando||dadosBloqueados)return;
 const {tipo,i,item}=editando,mat=tipo==='material',lista=mat?materiais:guardados;
 if(i!==null && lista[i]!==item){fechar();return toast('O registro mudou. Abra a edição novamente.')}
 const valor=Number($(mat?'valorMaterial':'valorGuardadoInput').value);
 const nome=$('nomeMaterial').value.trim(),quantidade=Number($('quantidadeMaterial').value),mes=$('mesGuardado').value;
 if(!(valor>0&&Number.isFinite(valor)) || (mat && (!nome||!(quantidade>0)||!Number.isFinite(quantidade*valor))) || (!mat && !mes))return toast('Confira os campos do registro.');
 const novo=mat?{...item,nome,quantidade,valor}:{...item,mes,valor};
 if(i===null)lista.push(novo);else lista[i]=novo;
 fechar();alterou(mat?'Material salvo.':'Valor guardado salvo.');
}
function exportar(){
 const blob=new Blob([JSON.stringify({exportado_em:new Date().toISOString(),...dadosAtuais()},null,2)],{type:'application/json'});
 const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='buildcontrol-backup-'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),3000);
}
function avisoConflito(remoto){
 conflito=remoto;status('Revisar cópias');
 let el=$('conflito');
 if(!el){
  el=document.createElement('article');el.id='conflito';el.className='panel';
  el.innerHTML='<h2>Cópias diferentes</h2><p>Os registros deste aparelho diferem da conta. Exporte um backup e escolha a cópia que deseja usar.</p><div class="actions"><button data-copy="local" class="action secondary">Manter neste aparelho e sincronizar</button><button data-copy="conta" class="action secondary">Carregar da conta</button><button id="backupConflito" class="link">Exportar backup local</button></div>';
  document.querySelector('.content').prepend(el);$('backupConflito').onclick=exportar;
 }
}
async function dadosDaConta(headers){
 const r=await fetch(api+'/api/dados',{headers,cache:'no-store',signal:AbortSignal.timeout(12000)});
 if(!r.ok)throw Error(String(r.status));
 const d=await r.json();
 if(!Array.isArray(d.materiais)||!Array.isArray(d.guardados))throw Error('Formato');
 return d;
}
async function sincronizar(){
 if(previa||!sessao?.access_token||sincronizando||conflito||dadosBloqueados)return;
 if(!navigator.onLine){status('Salvo no aparelho');return}
 sincronizando=true;
 const versao=revisao,headers={Authorization:'Bearer '+sessao.access_token};
 try{
  if(localStorage.getItem(chave('pendente'))!=='1'){
   const d=await dadosDaConta(headers);
   if(versao!==revisao)return;
   const assinatura=valores(dadosAtuais()),base=localStorage.getItem(chave('base'));
   if((materiais.length||guardados.length)&&valores(d)!==assinatura&&base!==assinatura){avisoConflito(d);return}
   preencher(d);salvarLocal();
  }else{
   const atual=await dadosDaConta(headers),base=localStorage.getItem(chave('base'));
   if(versao!==revisao)return;
   // A API existente salva a lista inteira. Confira a cópia remota antes de reenviar edições offline.
   if(valores(atual)!==valores(dadosAtuais()) && valores(atual)!==base && (base!==null || atual.materiais.length || atual.guardados.length)){
    avisoConflito(atual);return;
   }
   const assinaturaEnviada=valores(dadosAtuais());
   const r=await fetch(api+'/api/dados',{method:'POST',signal:AbortSignal.timeout(12000),headers:{...headers,'Content-Type':'application/json'},body:JSON.stringify(dadosAtuais())});
   if(!r.ok)throw Error(String(r.status));
   if(versao!==revisao){localStorage.setItem(chave('base'),assinaturaEnviada);return}
   localStorage.removeItem(chave('pendente'));
  }
  localStorage.setItem(chave('base'),valores(dadosAtuais()));status('Salvo na conta');
 }catch(e){
  status(e.message==='401'?'Sessão expirada':'Salvo no aparelho');
  if(e.message==='401'){$('btnSair').hidden=false;texto('btnSair','Entrar novamente');}
 }finally{
  sincronizando=false;if(versao!==revisao && !conflito)void sincronizar();
 }
}
function sair(){
 if(!confirm('Encerrar a sessão neste aparelho?'))return;
 if(conta)localStorage.setItem('buildcontrol_backup_conta_'+conta,JSON.stringify({...dadosAtuais(),pendente:localStorage.getItem(chave('pendente')),base:localStorage.getItem(chave('base'))}));
 for(const k of ['session','user','materiais','guardados','pendente','base'])localStorage.removeItem(chave(k));
 localStorage.setItem('buildcontrol_saiu','1');location.replace('./login.html');
}
document.addEventListener('click',e=>{
 const b=e.target.closest('button');if(!b)return;
 if(b.dataset.goView){const v=b.dataset.goView;if(location.hash==='#'+v)navegar(v);else location.hash=v}
 else if(b.dataset.openModal)abrir(b.dataset.openModal);
 else if(b.dataset.edit)abrir(b.dataset.edit,Number(b.dataset.id));
 else if(b.dataset.remove&&!dadosBloqueados){
  const mat=b.dataset.remove==='material';if(!confirm(mat?'Excluir este material?':'Excluir este valor guardado?'))return;
  (mat?materiais:guardados).splice(Number(b.dataset.id),1);alterou('Registro excluído.');
 }else if(b.dataset.copy&&conflito){
  if(!confirm('Usar a cópia selecionada?'))return;
  const remoto=conflito;conflito=null;$('conflito').remove();
  if(b.dataset.copy==='conta'){preencher(remoto);salvarLocal();localStorage.removeItem(chave('pendente'));localStorage.setItem(chave('base'),valores(remoto));status('Salvo na conta')}
  else {localStorage.setItem(chave('base'),valores(remoto));alterou('Cópia local selecionada.');}
 }
});
$('btnResetar').onclick=()=>{if(!dadosBloqueados&&confirm('Apagar TODOS os materiais e valores guardados desta obra?')){materiais=[];guardados=[];alterou('Materiais e reservas apagados.')}};
$('btnSair').onclick=sair;$('btnExportar').onclick=exportar;
$('fecharModal').onclick=fechar;$('modal').addEventListener('close',()=>{editando=null});
$('formMaterial').onsubmit=salvarForm;$('formGuardado').onsubmit=salvarForm;
$('buscaMaterial').oninput=e=>{busca=e.target.value;listaMateriais()};$('filtro').onchange=e=>{filtro=e.target.value;listaMateriais()};
window.addEventListener('hashchange',()=>navegar(location.hash.slice(1)));
window.addEventListener('online',sincronizar);
window.addEventListener('offline',()=>status('Salvo no aparelho'));
window.addEventListener('storage',e=>{if(e.key===chave('materiais')||e.key===chave('guardados')){revisao++;preencher(lerBackup())}});
function iniciar(){
 const legado=localStorage.getItem('materiais')!==null||localStorage.getItem('guardado')!==null;
 const guardadoAnonimo=localStorage.getItem(chave('materiais'))!==null && !localStorage.getItem(chave('dono'));
 if(!previa && !sessao?.access_token && (localStorage.getItem('buildcontrol_saiu')||(!legado&&!guardadoAnonimo))){location.replace('./login.html');return}
 if(!previa&&sessao?.access_token&&conta){
  const dono=localStorage.getItem(chave('dono'));
  if((dono && dono!==String(conta))||localStorage.getItem('buildcontrol_saiu')){
   const d=ler('buildcontrol_backup_conta_'+conta,{materiais:[],guardados:[]});materiais=d.materiais;guardados=d.guardados;salvarLocal();
   for(const k of ['pendente','base']){if(d[k])localStorage.setItem(chave(k),d[k]);else localStorage.removeItem(chave(k))}
  }
  localStorage.setItem(chave('dono'),conta);localStorage.removeItem('buildcontrol_saiu');
 }
 try{preencher(lerBackup());salvarLocal()}catch{dadosBloqueados=true;status('Backup requer revisão');toast('O backup não pôde ser lido. Os registros originais foram preservados.');return}
 status(previa?'Prévia local':'Neste aparelho');texto('obraTipo',previa?'Obra demonstrativa':'Painel da obra');
 texto('perfilInfo',previa?'Prévia com dados fictícios salvos neste navegador.':usuario?.email||'Dados salvos neste navegador.');
 $('btnSair').hidden=previa||!sessao;const hoje=new Date();texto('today',hoje.toLocaleDateString('pt-BR',{day:'numeric',month:'short',year:'numeric'}).replaceAll(' de ',' '));
 navegar(location.hash.slice(1),false);void sincronizar();
}
iniciar();
