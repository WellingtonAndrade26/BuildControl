// Prévia isolada. O pacote de atualização usa o modo "conta".
const MODO_BUILD = "previa";
