(() => {
 let promptInstalar=null, recarregar=false;
 const instalado=window.matchMedia('(display-mode: standalone)').matches;
 const botao=document.getElementById('btnInstalarPerfil');
 function informar(msg){if(typeof toast==='function')toast(msg)}
 if(botao){
   if(instalado)botao.hidden=true;
   botao.onclick=async()=>{
     if(!promptInstalar){informar('No menu do navegador, escolha “Instalar aplicativo” ou “Adicionar à Tela de Início”.');return}
     await promptInstalar.prompt();await promptInstalar.userChoice;promptInstalar=null;
   };
 }
 window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();promptInstalar=event});
 window.addEventListener('appinstalled',()=>{if(botao)botao.hidden=true;promptInstalar=null;informar('BuildControl instalado.')});
 if(!('serviceWorker' in navigator))return;
 const jaControlado=!!navigator.serviceWorker.controller;
 navigator.serviceWorker.addEventListener('controllerchange',()=>{
   if(!jaControlado||recarregar)return;
   recarregar=true;
   const modal=document.querySelector('dialog[open]');
   if(modal)modal.addEventListener('close',()=>location.reload(),{once:true});
   else if(document.activeElement?.closest('form'))informar('Atualização disponível. Reabra o aplicativo após salvar.');
   else location.reload();
 });
 window.addEventListener('load',async()=>{
  try{const reg=await navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'});if(jaControlado && navigator.onLine && !reg.installing)await reg.update()}catch{/* Offline: o worker instalado continua atendendo a página. */}
 });
})();
